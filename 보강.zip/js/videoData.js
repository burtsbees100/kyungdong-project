export default [
    {
        videoId: 'pSUydWEqKwE',
        videoSrc: 'https://www.youtube.com/embed/pSUydWEqKwE',
        thumbNailSrc: 'https://img.youtube.com/vi/pSUydWEqKwE/0.jpg',
        title: 'New Jeans(뉴진스) - Ditto',
        uploader: 'New Jeans',
    },
];
